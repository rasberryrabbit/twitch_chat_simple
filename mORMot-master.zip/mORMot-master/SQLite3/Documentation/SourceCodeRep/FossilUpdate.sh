#!/bin/bash

fossil pull
fossil update