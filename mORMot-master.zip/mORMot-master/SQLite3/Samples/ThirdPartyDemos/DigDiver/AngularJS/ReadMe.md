# Scope

Some part of an *AngularJS* client to a *mORMot* server.

It features login, with full authentication via a pure JavaScript / AngularJS client.

It is not a working demo, just some sources to get implementation ideas, and working code for authentication on a *mORMot* server.

To understand how it works is better to download Software (*G-Lock EasyMail*) as presented in topic http://synopse.info/forum/viewtopic.php?id=1954

# Forum Thread

See http://synopse.info/forum/viewtopic.php?pid=12547#p12547


**enjoy!**

DigDiver
